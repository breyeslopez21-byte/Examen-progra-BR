
import java.io.IOException;
import java.util.Scanner;
 
 
public class App {
    public static void main(String[] args) {
         Logica lg= new Logica();
        try( Scanner sc = new Scanner(System.in)){
            System.out.println("Ingrese su nombre: ");
            String nombre = sc.nextLine();
            System.out.println("Ingrese su correo: ");
           String correo = sc.nextLine();
            lg.guardar(nombre, correo);

        }catch( IOException e){
            System.out.println(e.getMessage());
            for ( Throwable sup: e.getSuppressed()){
                System.out.println(sup.getMessage());
            }
        }catch(Exception e){
            System.out.println(e.getMessage());
            }
    }
}