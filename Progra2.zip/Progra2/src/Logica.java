import java.io.IOException;

public class Logica {
     private Datos datos = null;
 
public void guardar (String nombre, String correo) throws IOException{
datos=new Datos("datos.txt");
datos.resgistro= nombre + "," + correo;
datos.guardarRegistro();
 
 
}
 
}
