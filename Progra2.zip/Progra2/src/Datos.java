
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
 
 
public class Datos {
    //{}
    public String  UsuarioDAOArchivo, resgistro;
    public Datos (String  UsuarioDAOArchivo)  {
    this. UsuarioDAOArchivo= UsuarioDAOArchivo;
    }
    public void guardarRegistro() throws IOException {
        try( BufferedWriter bw = new BufferedWriter(new FileWriter(this.UsuarioDAOArchivo, true))){
        bw.append(this.resgistro);
        bw.newLine();
    
        }
    }

 
}